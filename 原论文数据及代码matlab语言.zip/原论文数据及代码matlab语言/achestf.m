%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Estimates the parameters of an power ACH(n1,n2) model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   q 	[TxN] binary event series; T is lenght, N is number of series
%   Xi  set of regressors of length T; first column must be a vector of
%       constants
%   p0  seed for optimisation routine, can be input as [] for a random seed

function [phat, ses, logl] = achestf(Q,Xi,p0)

%   Preliminary stuff
T  = size(Q,1);     %   length of sample
M  = size(Q,2);     %   number of samples
k  = size(Xi,2);    %   number of intercept parameters
n1 = 1;             %   lag length for u
n2 = 1;             %   lag length for psi
ep = -1e-5;         %   small number
D  = 0.10;          %   smoothing parameter

%   Allocate space for estimates, standard errors
phat = zeros(M,k+n1+n2+1);
ses  = phat;
logl = zeros(M,1);

%   Optimisation settings
ops = optimset('Display',       'iter',  ...
               'MaxIter',       100000,  ...
               'MaxFunEvals',   200000,  ...
               'TolFun',        1e-10,   ...
               'TolX',          1e-10);

%   Constraints for optimisation procedure
A = [zeros(n1+n2+2,k) [-eye(n1+n2+1); [ones(1,n1+n2) 0]]];
b = [ep*ones(n1+n2+1,1); 1];

%   Loop through and estimate
for i = 1:M
    
    %   Current sample
    q  = Q(:,i);
    X  = Xi(:,:,i);
    p0i = p0(:,i);
    
    %   Constrained estimation
%     [p1,l] = fminsearch(@(p) achloglf(p,q,X,T,k,n1,n2,D),p0,ops);
    [p1,l] = fminsearchcon(@(p) achloglf(p,q,X,T,k,n1,n2,D),p0i,...
             [],[],A,b,[],ops);
%     [p1,l] = fmincon(@(p) achloglf(p,q,X,T,k,n1,n2,D),...
%              p0i,A,b,[],[],[],[],[],ops);
    
    %   Replace estimates
    phat(i,:) = p1';
    logl(i,1) = -l;
    
    %   Determine standard errors
    gt       = numgrad(@achlogltf,p1,q,X,T,k,n1,n2,D);
    J        = gt'*gt;
    B        = hessian(@achloglf,p1,q,X,T,k,n1,n2,D);
    ses(i,:) = sqrt(diag(inv(B/T)*J/T^2*inv(B/T)));
    
end

phat = phat';
ses  = ses';
