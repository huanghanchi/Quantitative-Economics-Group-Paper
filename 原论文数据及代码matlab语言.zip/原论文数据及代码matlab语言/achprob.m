%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Estimates probit model for ones of ACH(n1,n2) model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [phat, ses, logl] = achprob(P,Xi,p0)

%   Preliminary stuff
T  = size(P,1);     %   length of sample
M  = size(P,2);     %   number of samples
k  = size(Xi,2);    %   number of intercept parameters
c  = 1;             %   (number of categories)-1

%   Marks for point process
ix1    = (P >= 100) & (P < 300);
ix2    = (P >= 300); 
Y      = zeros(T,M);
Y(ix1) = 1;
Y(ix2) = 2;

%   Allocate space for estimates, standard errors
phat = zeros(size(p0));
ses  = phat;
logl = zeros(M,1);

%   Random seed for optimisation routine, if necessary
if isempty(p0) == 1, p0 = randn(1,k+c)'; end

%   Optimisation settings
ops = optimset('Display',       'iter',  ...
               'MaxIter',       100000,  ...
               'MaxFunEvals',   200000,  ...
               'TolFun',        1e-7,    ...
               'TolX',          1e-7);

%   Optimisation constraints
A = [1 -1 zeros(1,k)];
b = 1e-6;

%   Loop through and estimate
for i = 1:M
    
    %   Current sample
    y   = Y(:,i);
    ix  = y ~= 0;
    y   = y(ix);
    X   = Xi(ix,:,i);
    p0i = p0(:,i);
    
%       Optimisation
    [p1,l] = fminsearch(@(p) proplogl(p,y,X,c,k),p0i,ops);
    
%     [p1,l] = fminsearchcon(@(p) proplogl(p,y,X,c,k),p0i,...
%              [],[],A,b,[],ops);
    
%     [p1,l] = fmincon(@(p) proplogl(p,y,X,c,k),...
%              p0i,A,b,[],[],[],[],[],ops);

  
    %   Replace estimates
    phat(:,i) = p1;
    logl(i,1) = -l;
    
    %   Determine standard errors
    gt       = numgrad(@proploglt,p1,y,X,c,k);
    J        = gt'*gt;
    B        = hessian(@proplogl,p1,y,X,c,k);
    ses(i,:) = sqrt(diag(inv(B/T)*J/T^2*inv(B/T)));
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Sub routine to compute -loglikelihood

function l = proplogl(p,y,X,c,k)

lt = proploglt(p,y,X,c,k);
l  = -sum(lt);

function lt = proploglt(p,y,X,c,k)

y  = y-1;
t  = size(y,1);
lt = zeros(t,1);
g  = normcdf(X*p);
lt = y.*log(g) + (1-y).*log(1-g);

a = 0;









