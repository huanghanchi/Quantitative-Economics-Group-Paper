%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Simulate the ACH model from estimated parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   q 	T*1 binary event series
%   X   set of regressors of length T
%   p   estimated parameters

function Q = achsim(q,p,X)

%   Preliminary stuff
T  = size(q,1);             %   length of sample
k  = size(X,2);             %   additional parameters beyond n1,n2
n1 = 1;                     %   values for ACH(n1,n2) model
n2 = 1;
n  = max(n1,n2)+1;
K  = 1;                     %   number of simulations
Q  = zeros(T,K);
D  = 0.10;

%   Seed simulation
rand('seed',7777777)

%   Pull out parameters
g  = p(1:k,1);
if n1 ~= 0, a  = p(k+1:k+n1,1); else a = []; end
if n2 ~= 0, b  = p(k+n1+1:k+n1+n2,1); else b = []; end
a0 = (X*g);

%   Generate N, u, psi
N      = cumsum(q);
ix     = find(q == 1);
u      = ix(2:N(T))-ix(1:N(T)-1);
ubar   = mean(u);
psibar = ubar*sum(a)/(1-sum(b));


%   Loop through the series recalculating hazard rate recursively, so that
%   if u <= h_t then an exceedence occurs and qsim(t) = 1, else qsim(t) = 0

for i = 1:K
    
    u = rand(T,1);
    
    %   Seed until the first interval is observed
    ht        = ones(T,1);
    ht(1)     = 0;
    ht(2:T,1) = ht(2:T,1)./(psibar+a0(2:T,:));

    ix           = find(u <= ht);
    Q(ix(1:n),i) = 1;
    
    l = ix(n)+1;
    
    while l < T
        
        ht  = achht(p,Q(:,i),X,T,k,n1,n2,D);
        ixl = find(u(l:T,1) <= ht(l:T,1));
        
        if isempty(ixl) == 1; break, end
        
        Q(ixl(1)+l,i) = 1;
        l = ixl(1)+l;
        
    end

end

