%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   return log likelihood at each observation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [loglt ht] = uncondloglt(p,q,X,T,D)

% ht = 1./lambda(X*p,D,T);
ht = 1./(1 + exp(-X*p));
loglt = q(1:T).*log(ht(1:T)) + (1-q(1:T)).*log(1-ht(1:T));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   sub-routine to perform smoothing

function l = lambda(nu,D,T)

X      = zeros(T,1);
ix1    = nu <= 1;
X(ix1) = 1.0001;
ix3    = nu >= 1+D;
X(ix3) = 0.0001+nu(ix3);
ix2    = (1 < nu) & (nu < 1+D);
X(ix2) = 1.0001+(2*D*(nu(ix2)-1).^2)./(D^2+(nu(ix2)-1).^2);
l      = X;


