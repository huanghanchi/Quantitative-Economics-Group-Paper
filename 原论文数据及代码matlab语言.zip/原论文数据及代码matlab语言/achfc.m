%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Evaluate the forecast performance of the models out of sample
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [AERR UERR hta htu] = achfc(Q,Xi,pu,pa_3)

Tst = 149856;       %   Start of the forecast period
M   = size(Q,2);    %   Number of states
k   = size(Xi,2);   %   Number of factors
n1  = 1;            %   ACH(n1,n2) parameters
n2  = 1;            %   ACH(n1,n2) parameters
D   = 0.10;         %   Smoothing parameter

AERR = zeros(4,M);
UERR = AERR;
plno = 1;



%   Loop through the states
for i = 1:M
    
%     figure(1)
    
    q = Q(:,i);
    X = Xi(:,:,i);
%     T = size(q,1);
    T = 154224;
    
    %   ACH hazards
    p   = pa_3(:,i);
    htafull = achhtf(p,q,X,T,k,n1,n2,D);
%     mean(hta)
           
    %   Unconditional hazards
    p           = pu(:,i);
    [loglt htufull] = uncondloglt(p,q,X,T,D);
        
    %   Trim for forecast period
    q   = q(Tst:T,1);
    htu(:,i) = htufull(Tst:T,1);
    hta(:,i) = htafull(Tst:T,1);
    
%     subplot(M,1,i)
%     hold on
%     bar(q,'EdgeColor','none','FaceColor',[0.8 0.8 0.8])
%     plot(hta,'k')
%     plot(htu,'-.r','LineWidth',1)
% %     plot(q - 0.5,'*k')
% 
%     axis([0 size(q,1)+1 -0.05 1.05])
%     hold off
%     plno = plno+1;
%     set(gca,'XTick',(1:1455:4400))
%     set(gca,'XTickLabel',{'01-Jul-07','01-Aug-07','01-Sep-07','01-Oct-07'})
%     
%     if i == 1
%         figure(2)
%         
%         subplot(4,1,1)
%         hold on
%         bar(q,'EdgeColor','none','FaceColor',[0.8 0.8 0.8])
%         plot(hta,'k')
% %         plot(htu,'-.r','LineWidth',1)
%         %     plot(q - 0.5,'*k')
% 
%         axis([0 size(q,1)+1 -0.05 1.05])
%         hold off
%         plno = plno+1;
%         set(gca,'XTick',(1:1455:4400))
%         set(gca,'XTickLabel',{'01-Jul-07','01-Aug-07','01-Sep-07','01-Oct-07'})
%         
%         subplot(4,1,2)
%         hold on
%         bar(q,'EdgeColor','none','FaceColor',[0.8 0.8 0.8])
% %         plot(hta,'k')
%         plot(htu,'k','LineWidth',1)
%         %     plot(q - 0.5,'*k')
% 
%         axis([0 size(q,1)+1 -0.05 1.05])
%         hold off
%         plno = plno+1;
%         set(gca,'XTick',(1:1455:4400))
%         set(gca,'XTickLabel',{'01-Jul-07','01-Aug-07','01-Sep-07','01-Oct-07'})
%         
%     end
%     
%     if i == 2
%         figure(2)
%         
%         subplot(4,1,3)
%         hold on
%         bar(q,'EdgeColor','none','FaceColor',[0.8 0.8 0.8])
%         plot(hta,'k')
% %         plot(htu,'-.r','LineWidth',1)
%         %     plot(q - 0.5,'*k')
% 
%         axis([0 size(q,1)+1 -0.05 1.05])
%         hold off
%         plno = plno+1;
%         set(gca,'XTick',(1:1455:4400))
%         set(gca,'XTickLabel',{'01-Jul-07','01-Aug-07','01-Sep-07','01-Oct-07'})
%         
%         subplot(4,1,4)
%         hold on
%         bar(q,'EdgeColor','none','FaceColor',[0.8 0.8 0.8])
% %         plot(hta,'k')
%         plot(htu,'k','LineWidth',1)
%         %     plot(q - 0.5,'*k')
% 
%         axis([0 size(q,1)+1 -0.05 1.05])
%         hold off
%         plno = plno+1;
%         set(gca,'XTick',(1:1455:4400))
%         set(gca,'XTickLabel',{'01-Jul-07','01-Aug-07','01-Sep-07','01-Oct-07'})
%         
%     end
    
        


    %   Print predictions, etc
    cutoff = 0.5;
    fprintf('Actual events:         %4.0f\n',sum(q))
    fprintf('ACH correct:           %4.0f\n',sum( (q == 1) & (hta(:,i) >= cutoff) ))
    fprintf('Uncond correct:        %4.0f\n',sum( (q == 1) & (htu(:,i) >= cutoff) ))
    fprintf('ACH false alarms       %4.0f\n',sum( (q == 0) & (hta(:,i) >= cutoff) ))
    fprintf('Uncond false alarms    %4.0f\n',sum( (q == 0) & (htu(:,i) >= cutoff) ))
    fprintf('\n')


    
    %   Measures of performance
    AERR(1,i) = mean(abs(q-hta(:,i)));
    UERR(1,i) = mean(abs(q-htu(:,i)));
    
    AERR(2,i) = sqrt(mean((q-hta(:,i)).^2));
    UERR(2,i) = sqrt(mean((q-htu(:,i)).^2));
    
    AERR(3,i) = -mean( (1-q).*log(1-hta(:,i)) + q.*log(hta(:,i)) );
    UERR(3,i) = -mean( (1-q).*log(1-htu(:,i)) + q.*log(htu(:,i)) );
    
    ix1 = find(q == 1);
    ix2 = find(q == 0);
    
    deva = zeros(size(q));
    devu = deva;
    
    deva(ix1) = 1.5*abs(q(ix1) - hta(ix1,i));
    deva(ix2) = 0.5*abs(q(ix2) - hta(ix2,i));
    AERR(4,i) = mean(deva);
    
    devu(ix1) = 1.5*abs(q(ix1) - htu(ix1,i));
    devu(ix2) = 0.5*abs(q(ix2) - htu(ix2,i));
    UERR(4,i) = mean(devu);
    
end