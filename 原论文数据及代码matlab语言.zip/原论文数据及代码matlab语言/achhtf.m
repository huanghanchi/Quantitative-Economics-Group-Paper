%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Return the hazard at each observation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ht psibar ubar] = achhtf(p,q,X,T,k,n1,n2,D)

%   Preliminary stuff
g  = p(1:k,1);
if n1 ~= 0, a  = p(k+1:k+n1,1); else a = []; end
if n2 ~= 0, b  = p(k+n1+1:k+n1+n2,1); else b = []; end
a0 = (X*g);
nu = p(end);

%   Generate N, u, psi vectors
N      = cumsum(q);
ix     = find(q == 1);
u      = ix(2:N(T))-ix(1:N(T)-1);
ubar   = mean(u);
psibar = ubar*sum(a)/(1-sum(b));

%   Move so no negative indices
n        = max(n1,n2);
psi      = zeros(N(T)+n,1);
psi(1:n) = psibar;
u        = [zeros(n,1); u];
u(1:n,1) = ubar;

%   Loop through
if n1 ~= 0 && n2 ~= 0
    for i = 1:N(T)
        psi(i+n) = (a'*u(i+n-n1:i+n-1,1).^nu+b'*psi(i+n-n2:i+n-1).^nu).^(1/nu);
    end
elseif n2 == 0 && n1 ~= 0
    for i = 1:N(T)
        psi(i+n) = (a'*u(i+n-n1:i+n-1,1).^nu).^(1/nu);
    end
elseif n1 == 0 && n2 ~= 0
    for i = 1:N(T)
        psi(i+n) = (b'*u(i+n-n2:i+n-1,1).^nu).^(1/nu);
    end
end

%   Move back
psi = psi(n+1:n+N(T));

Nu = zeros(T,1);
%   calculate hazards
k = find(N(1:T) == 1,1);
Nu(1:k,1) = exp(-a0(1:k,1)) + psibar;
Nu(k+1:T) = exp(-a0(k+1:T,1)) + psi(N(k:T-1));


% for i = 1:T
%     if i == 1
%         nu(i) = exp(a0(i)) + psibar;
%     elseif N(i-1) == 0
%         nu(i) = exp(a0(i)) + psibar;
%     else
%         nu(i) = exp(a0(i)) + psi(N(i-1));
%     end
% end
% ix0     = N == 0;
% ix1     = N ~= 0;
% nu(ix0) = exp(a0(ix0)) + psibar;
% nu(ix1) = exp(a0(ix1)) + psi(N(ix1));
ht      = 1./lambda(Nu,D,T);
% % % ht      = 1./nu';
wxyz = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   sub-routine to perform smoothing

function l = lambda(Nu,D,T)

X      = zeros(T,1);
ix1    = Nu <= 1;
X(ix1) = 1.0001;
ix3    = Nu >= 1+D;
X(ix3) = 0.0001+Nu(ix3);
ix2    = (1 < Nu) & (Nu < 1+D);
X(ix2) = 1.0001+(2*D*(Nu(ix2)-1).^2)./(D^2+(Nu(ix2)-1).^2);
l      = X;