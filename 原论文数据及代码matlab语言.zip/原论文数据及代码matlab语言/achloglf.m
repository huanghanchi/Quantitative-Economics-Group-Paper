%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Return the summed -log-likelihood at each observation for the Hamilton
%   and Jorda ACH model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function logl = achloglf(p,q,X,T,k,n1,n2,D)

loglt = achlogltf(p,q,X,T,k,n1,n2,D);
logl  = -sum(loglt);
