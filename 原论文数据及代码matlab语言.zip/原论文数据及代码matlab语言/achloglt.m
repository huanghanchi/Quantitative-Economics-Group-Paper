%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Return the log-likelihood at each observation for the Hamilton
%   and Jorda ACH model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function loglt = achloglt(p,q,X,T,k,n1,n2,D)

ht    = achht(p,q,X,T,k,n1,n2,D);
loglt = q(1:T).*log(ht(1:T)) + (1-q(1:T)).*log(1-ht(1:T));