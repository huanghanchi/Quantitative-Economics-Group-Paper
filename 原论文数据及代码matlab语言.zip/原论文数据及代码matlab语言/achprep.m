%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Prepare data for ACH estimation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Q Xi] = achprep(p,l,temp,nd)

T    = size(p,1);  %   Length of time
N    = size(p,2);  %   Number of estimations
co   = 6;          %   Number of columns: constant, load, hot temp, cold temp, peak, weekend
cut  = 100;        %   Cutoff
tmin = 07;         %   Start for peak dummy
tmax = 22;         %   End for peak dummy

%   Allocate space
Q  = zeros(T,N);
Xi = zeros(T,co,N);

wd = weekday(nd);

%   Loop through and arrange data
for i = 1:N
    %   Price exceedences
    Q(:,i) = p(:,i) >= cut;
    
    %   Constant
    Xi(:,1,i) = ones(T,1);
    
    %   Peak variable
    [y,mo,d,h] = datevec(nd);
    ix = (h >= tmin) & (h <= tmax) & (wd ~= 1) & (wd ~= 7);
    Xi(:,5,i) = ix;
    
    %   Load data - standardise by the previous years' data
    Xi(1:48*365,2,i) = (l(1:48*365,i)-mean(l(1:48*365,i)))./std(l(1:48*365,i));
    for j = 48*365+1:T
        Xi(j,2,i) = (l(j,i)-mean(l(j-48*365:j,i)))./std(l(j-48*365:j,i));
    end
    
    %   Temperature data
%     y = zeros(size(Xi(:,1,1)));
%     for j = 1:T/48
%         if j <= 365
%             y((j-1)*48+1:j*48,1) = ( temp(j,1,i)-mean(temp(1:365,1,i)) );
%         else
%             y((j-1)*48+1:j*48,1) = ( temp(j,1,i)-mean(temp(j-365:j,1,i)) );
%         end
%     end
%     
%     ix1 = (y >= 0);
%     ix2 = (y <= 0);
%     
%     Xi(ix1,3,i) = y(ix1);
%     Xi(ix2,4,i) = y(ix2);

    for j = 1:T/48

        if j <= 365
            
            Xi((j-1)*48+1:j*48,3,i) = abs( temp(j,1,i)-mean(temp(1:365,1,i)) );
            Xi((j-1)*48+1:j*48,4,i) = abs( temp(j,2,i)-mean(temp(1:365,2,i)) );
            
        else
            
            Xi((j-1)*48+1:j*48,3,i) = abs( temp(j,1,i)-mean(temp(j-365:j,1,i)) );
            Xi((j-1)*48+1:j*48,4,i) = abs( temp(j,2,i)-mean(temp(j-365:j,2,i)) );
            
        end

    end
    
    %   Weekend dummy
    ix = (wd == 7 | wd == 1);
    Xi(:,6,i) = ix;
    
end