%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Estimates the parameters of an unconditional intensity model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   q 	[TxN] binary event series; T is lenght, N is number of series
%   Xi  set of regressors of length T; first column must be a vector of
%       constants
%   p0  seed for optimisation routine, can be input as [] for a random seed

function [phat, ses, logl] = uncondest(Q,Xi,p0)

%   Preliminary stuff
T  = size(Q,1);     %   length of sample
M  = size(Q,2);     %   number of samples
k  = size(Xi,2);    %   number of intercept parameters
D  = 0.10;          %   smoothing parameter

%   Allocate space for estimates, standard errors
phat = zeros(M,k);
ses  = phat;
logl = zeros(M,1);

%   Random seed for optimisation routine, if necessary
if isempty(p0) == 1, p0 = zeros(k,M); end

%   Optimisation settings
ops = optimset('Display',       'iter',  ...
               'MaxIter',       100000,  ...
               'MaxFunEvals',   200000,  ...
               'TolFun',        1e-10,   ...
               'TolX',          1e-10);

%   Loop through and estimate
for i = 1:M
    
    %   Current sample
    q  = Q(:,i);
    X  = Xi(:,:,i);
    p0i = p0(:,i);
%     p0i = p0;
    
    %   Constrained estimation
    [p1,l] = fminsearch(@(p) uncondlogl(p,q,X,T,D),p0i,ops);
%     [p1,l] = fminunc(@(p) uncondlogl(p,q,X,T,D),p0i,ops);
    
    %   Replace estimates
    phat(i,:) = p1';
    logl(i,1) = -l;
    
    %   Determine standard errors
    gt       = numgrad(@uncondloglt,p1,q,X,T,D);
    J        = gt'*gt;
    ses(i,:) = sqrt(diag(inv(J)));
    
end

phat = phat';
ses  = ses';
